public class IngressoNormal extends Ingresso{
  private int Qntd;
  private float desconto;
  private float total;
  private float val; //NAO CONSIGO PUXAR O VALOR DA CLASSE INGRESSO :(


  public void CalcValor(float quant){

      if(quant>5 && quant<10){
        this.total=47.5f*quant;
      }

      if(quant>10 && quant<15){
        this.total=45.0f*quant;
      }
      if(quant>16.0f){

        this.total=42.5f;
      }
      else{
        this.total=50.0f*quant;
      }
      System.out.println("O total da compra foi de:"+this.total);


  }

  public float Showvalor(){
    System.out.println("O valor do ingresso comum é:"+this.total);
    return this.val;
  }

  public float getValor(){
    return this.val;
  }
  //
  // public float setValor(){}
}
