import java.util.Scanner;
import java.util.Arrays;
public class Ingresso {
private  float valor;

public float Ingresso(){
  return this.valor = 50.0f;
}

  public float MostraValor(){
    System.out.println("O valor integral do ingresso é:"+this.valor);
    return this.valor;
  }
}
