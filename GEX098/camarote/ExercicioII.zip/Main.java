﻿//Acadêmica: Any Cruz S. 1721101005 - Programação I 2018 2
import java.util.Scanner;
import java.util.Arrays;

public class Main {
 public static void main(String[] args) {
   Scanner sc = new Scanner(System.in);
   int op=1,q,p;
    while (op!=0)
    {
    System.out.println("\nBEM-VIND@!\n");
    System.out.println("\nPor favor, digite o numero correspondente a opcao desejada.\n\n1- Comprar ingresso normal.\n2- Comprar ingresso VIP\n\n\n\n");
    op = sc.nextInt();
		switch (op)
		{
			case 1: {
        System.out.println("INGRESSO NORMAL\n\n");
        Ingresso x = new Ingresso();
        System.out.println("O valor unitario do ingresso comum eh de:"+x.Ingresso()+"\n");
        System.out.println("Por favor, informe a quantidade de ingressos:");
        q = sc.nextInt();
        IngressoNormal j = new IngressoNormal();
        j.CalcValor(q);

        break;

        // if(0<q<5){
        //   IngressoNormal j = new IngressoNormal();
        //   j.CalcValor(q);
        // }
        //
        // if(5<=q<=10){
        //   IngressoNormal a =  new IngressoNormal();
        //   a.CalcValor(q);
        // }
        // if(q>15){
        //   IngressoNormal l =  new IngressoNormal();
        //   l.CalcValor(q);
        // }
      }

    case 2:{

      float vip;
      System.out.println("INGRESSO VIP E CAMAROTES\n\n");
      System.out.println("Informe a opcao desejada:");
      System.out.println("1- Ingresso VIP\n2- Camarote Superior\n3-Camarote Inferior\n");
      p = sc.nextInt();
      if(p==1){
        IngressoVIP w = new IngressoVIP();
        System.out.println("O valor do ingresso vip consiste em "+w.getValorVIP()+ " + Adicional\n");
        System.out.println("Informe a quantidade desejada de ingressos VIP.");
        vip = sc.nextFloat();
        System.out.print("Total a ser pago: R$");
        w.setquantidadeVIP(vip);
      }
      if(p==2){
        float cm;
        CamaroteSuperior d = new CamaroteSuperior();
        System.out.println("O valor do camarote superior consiste em "+d.getCS()+" + Adicional");
        System.out.println("Informe a quantidade desejada de reservas correspondentes ao camarote superior.");
        cm = sc.nextFloat();
        System.out.print("Total a ser pago: R$");
        d.setQuantidadeCS(cm);
      }

      if(p==3){
        float ci,consumo;
        String place;


        CamaroteInferior z = new CamaroteInferior();
        z.setValorcam();
        System.out.println("O valor do camarote inferior consiste em "+z.getCamaroteInf());
        System.out.println("Digite em qual area deseja ficar:\n- Sul\n- Norte\n- Oeste\n- Leste.");
        place = sc.next();
        z.setLocalC(place);
        System.out.println("Informe a quantidade desejada de reservas correspondentes ao camarote inferior.");
        ci = sc.nextFloat();
        System.out.print("Total a ser pago: R$");
        z.setQuantidadeCI(ci);
        // z.getQuantidadeCI();
        System.out.println("Informe o total consumido.");
        consumo = sc.nextFloat();
        if(consumo<200.5f){
          z.setConsumoh(consumo);
        }
        if(consumo>=200.5f){
          z.setConsumoh(consumo);
        }



      }



      break;
    }

    // case 3:{
    //   exit(0);
    //
    // }

    default:{
      System.out.println("Comando inválido!\n");
      break;
    }

      }}}






   // IngressoNormal b = new IngressoNormal();
   // b.Showvalor();
   //
   // CamaroteInferior h = new CamaroteInferior();
   // h.Consumo();


 }
