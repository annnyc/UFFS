public class CamaroteInferior extends IngressoVIP{

  private String Local;
  private float VlrAdicional;
  private float DescontoConsumo;
  private float Consumototal;


  // public void CamaroteInferior(){
  //    this.VlrAdicional = 300.0f;}
  // }

public void setValorcam(){
  float ko=250.0f;
  this.VlrAdicional = ko;
}

  public String MostrarLocal(){
    System.out.println("O camarote inferior é localizado em:"+this.Local);
    return this.Local;
  }

  public void setConsumoh(float consumo){
    this.Consumototal=consumo;

    System.out.println("O total consumido foi de:"+this.Consumototal);
    System.out.println("Total do valor consumido com desconto:"+DSCON(consumo));
  }


  public float DSCON(float descon){
     if(descon>200.0f){
       descon=descon-(descon*0.11f);
       this.DescontoConsumo=descon;
       return this.DescontoConsumo;
     }

     if(descon>500.0f){
       descon=descon-(descon*0.15f);
       this.DescontoConsumo=descon;
       return this.DescontoConsumo;
     }
     return 0;
   }

  public void setLocalC(String lugar){
    this.Local = lugar;
    System.out.println(lugar);
  }

  public float getCamaroteInf(){
    setValorcam();
    return this.VlrAdicional;
  }

  public void setQuantidadeCI(float rt){
   rt=rt*this.VlrAdicional;
    System.out.println(rt);
  }
}
