public class IngressoVIP extends Ingresso{
  private float ValorAdicional;

  public void IngressoVIP(){
     this.ValorAdicional = 100.0f;
  }
  public float VlrIngressoVIP(){
    System.out.println("O valor do ingresso VIP é:"+this.ValorAdicional);
    return this.ValorAdicional;
  }

  public float getValorVIP(){
    IngressoVIP();
    return this.ValorAdicional;
  }



  public void setquantidadeVIP(float u){
    u=u*this.ValorAdicional;
    System.out.println(u);
  }


}
