public class CamaroteSuperior extends IngressoVIP{
  private float ValorAdicional;

  public void CamaroteSuperior(){
     this.ValorAdicional = 200.0f;
  }

  public float getCS(){
    CamaroteSuperior();
    return this.ValorAdicional;
  }

  public float MostVal(){
    System.out.println("O valor do camarote superior é:"+this.ValorAdicional);
    return this.ValorAdicional;
  }




  public void setQuantidadeCS(float xxx){
    xxx=xxx*this.ValorAdicional;
    System.out.println(xxx);
  }
}
