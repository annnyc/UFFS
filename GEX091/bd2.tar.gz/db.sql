CREATE TABLE "table" (
	"id" serial,
	"A" integer,
	"B" integer,
	"C" integer,
	"D" integer,
	"E" integer,
	"F" integer,
	"G" integer,
	"H" integer,
	"I" integer,
	CONSTRAINT "table_pk" PRIMARY KEY ("id")
);
