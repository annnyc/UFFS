const fs = require('fs');
const chalk = require('chalk');
const YAML = require('yaml');

const { Client } = require('pg')

const types = {
  START_TRANSACTION: 'START_TRANSACTION',
  DO_TRANSACTION: 'DO_TRANSACTION',
  COMMIT_TRANSACTION: 'COMMIT_TRANSACTION',
  CHECKPOINT: 'CHECKPOINT',
  END_CHECKPOINT: 'END_CHECKPOINT'
}

async function main() {
  const file = readFile();

  await populateDatabase(file);

  const log = parseFile(file);

  const itemsToVerify = getTransactionsCommited(log);

  const { rows: [dbTable] } = await query('SELECT * FROM "table" WHERE id = 1');

  const items = getItemsToUpdateOnDb(dbTable, itemsToVerify);

  await saveChangesOnDB(items);

  saveOutputLog(items);
 
  logChanges(items);
}

function saveOutputLog(items) {
  if (!fs.existsSync('./.output')) {
    fs.mkdirSync('./.output');
  }

  const doc = new YAML.Document();
  doc.contents = items;

  const fileName = `.output/${Date.now()}`;

  fs.writeFileSync(`${fileName}.json`, JSON.stringify(items, null, 2));
  fs.writeFileSync(`${fileName}.yaml`, doc.toString());
}

async function saveChangesOnDB(items) {
  await Promise.all([
    ...items.map(item =>
      query(`UPDATE "table" SET "${item.column}" = ${item.newValueList.slice(-1)[0]} WHERE "id" = 1`)
    )
  ]);
}

function logChanges(items) {
  const mainText = '---------------------------- ITEMS REDO ----------------------------'
  clearConsoleAndScrollbackBuffer();
  console.log(chalk.bgGreen(mainText));
  items.forEach(item => {
    const output = `Coluna: ${item.column} | OLD: ${item.oldValue} | NEW ${item.newValueList.slice(-1)[0]}`;
    const emptyCharacters = mainText.length - output.length;

    console.log(chalk.bgGreenBright(output + ' '.repeat(emptyCharacters)));
    item._raw.forEach(raw => {
      const output = `Transação: ${raw.transaction} alterou para: ${raw.value}`;
      const emptyCharacters = mainText.length - output.length;

      console.log(chalk.bgGreen(output + ' '.repeat(emptyCharacters)));
    })
    console.log(chalk.bgGreen('-').repeat(mainText.length));
  });
}

function getItemsToUpdateOnDb(dbTable, itemsToVerify) {
  return Object.keys(dbTable).slice(1).reduce((accumulator, key) => {
    const itemList = itemsToVerify.filter(transaction => transaction.column === key);

    if (itemList.length === 0) {
      return accumulator;
    }

    const newValueList = itemList.map(transaction => transaction.value);
    const oldValue = dbTable[key];

    const updatedDb = !newValueList.reduce((changed, currentValue) => changed && (currentValue == oldValue), true);

    accumulator.push({
      column: key,
      newValueList,
      oldValue,
      transactionList: itemList.map(item => item.transaction),
      updatedDb,
      _raw: itemList
    });

    return accumulator;
  }, []);
}

function getTransactionsCommited(log) {
  const commitedItems = log.filter(item => item.type === types.COMMIT_TRANSACTION);

  const itemsToVerify = log.reduce((accumulator, current) => {
    if (!(current.type === types.DO_TRANSACTION)) {
      return accumulator;
    }

    if (commitedItems.findIndex(item => item.transaction === current.transaction) < 0) {
      return accumulator;
    }

    accumulator.push(current);

    return accumulator;
  }, []);
  return itemsToVerify;
}

async function populateDatabase(file) {
  const parsedHeader = parseHeader(file);

  const { A, B, C, D, E, F } = parsedHeader;

  await query(`
  INSERT INTO public."table" (id, "A", "B", "C", "D", "E", "F") VALUES (1, ${A}, ${B}, ${C}, ${D}, ${E}, ${F})
  ON CONFLICT (id) DO UPDATE 
  SET "A" = excluded."A",
    "B" = excluded."B",
    "C" = excluded."C",
    "D" = excluded."D",
    "E" = excluded."E",
    "F" = excluded."F",
    "G" = excluded."G",
    "H" = excluded."H",
    "I" = excluded."I"
  WHERE "table".id = 1`
  );
}

async function query(sql) {
  const client = new Client({
    database: 'db2', host: 'localhost', user: 'postgres', password: '123456'
  });

  await client.connect();

  const res = await client.query(sql);

  await client.end();

  return res;
}

function parseFile(file) {
  const rawExpressions = parseExpressions(file);

  return rawExpressions.map(item => {
    if (/^\s*start\s*t/gmi.test(item)) {
      return {
        type: types.START_TRANSACTION,
        transaction: item.split(' ')[1].trim()
      };
    }

    if (/^\s*t\d+/gmi.test(item)) {
      const splitedItem = item.split(',').map(i => i.trim());

      return {
        type: types.DO_TRANSACTION,
        transaction: splitedItem[0],
        column: splitedItem[1],
        value: splitedItem[2]
      };
    }

    if (/^\s*commit/gmi.test(item)) {
      return {
        type: types.COMMIT_TRANSACTION,
        transaction: item.split(' ')[1].trim()
      };
    }

    if (/Start\s*CKPT/gmi.test(item)) {
      const regex = /\((.*)\)/gmi;

      return {
        type: types.CHECKPOINT,
        transactionList: regex.exec(item)[1].split(',').map(i => i.trim())
      };
    }

    if (/End\s*CKPT/gmi.test(item)) {
      return {
        type: types.END_CHECKPOINT,
      };
    }
  });
}

function parseExpressions(file) {
  const result = [];

  for (const match of file.matchAll(/<(.*)>/gmi)) {
    result.push(match[1]);
  }
  return result;
}

function readFile() {
  const file = fs.readFileSync('./file', 'utf8').trimLeft().trimRight();
  return file;
}

function parseHeader(file) {
  const header = file.split('\n').shift();

  return Object.assign({}, ...header.split('|').map(item => {
    const trimedItem = item.trim();

    const [key, value] = trimedItem.split('=');

    return {
      [key]: value
    };
  }));
}

function clearConsoleAndScrollbackBuffer() {
  process.stdout.write("\u001b[3J\u001b[2J\u001b[1J"); console.clear();
}

main();
